/*********************************************************************NVMH1****
File:
nv_util.h

Copyright (C) 1999, 2000 NVIDIA Corporation
This file is provided without support, instruction, or implied warranty of any
kind.  NVIDIA makes no guarantee of its fitness for a particular purpose and is
not liable under any circumstances for any damages or loss whatsoever arising
from the use or inability to use this file or items derived from it.

Comments:


******************************************************************************/

#ifndef __nv_util_h__
#define __nv_util_h__

// Disable the STL debug information warnings
#pragma warning (disable:4786)
#ifdef _WIN32
#include <windows.h>
#endif
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <setjmp.h>
#include <assert.h>
#include <vector>
#include <string>
#include <map>

#ifndef __nv_unzip_h__
#   include <nv_unzip.h>
#endif // __nv_unzip_h__

#ifndef __tga_h__
#   include <nv_tga.h>
#endif // __tga_h__

#ifndef __nv_jpeg_h__
#   include <nv_jpeg.h>
#endif // __nv_jpeg_h__

#ifndef __nv_ase_h__
#   include <nv_ase.h>
#endif // __nv_ase_h__

#endif // __nv_util_h__  
