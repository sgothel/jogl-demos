!!TS1.0
texture_2d();
dot_product_reflect_cube_map_eye_from_qs_1of3(expand(tex0));
dot_product_reflect_cube_map_eye_from_qs_2of3(expand(tex0));
dot_product_reflect_cube_map_eye_from_qs_3of3(expand(tex0));